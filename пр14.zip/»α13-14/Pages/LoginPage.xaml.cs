﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace пр13_14.Pages
{
    public partial class LoginPage : Page
    {
        private const string ConnectionString =
            @"Server=WIN-FQ3SEPJHQEH; Database=пр13; Integrated Security=true; TrustServerCertificate=True;";

        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox?.Text.Trim();
            string password = PasswordBox?.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = @"SELECT u.UserID, u.FullName, u.IsActive, r.RoleName 
                                     FROM Users u 
                                     LEFT JOIN Roles r ON u.RoleID = r.RoleID
                                     WHERE u.Login = @Login AND u.PasswordHash = @Password";

                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);
                        cmd.Parameters.AddWithValue("@Password", password);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string role = reader["RoleName"] != DBNull.Value
                                    ? reader.GetString(reader.GetOrdinal("RoleName"))
                                    : "User";
                                bool isActive = reader.GetBoolean(reader.GetOrdinal("IsActive"));

                                if (!isActive)
                                {
                                    MessageBox.Show("Аккаунт заблокирован", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    return;
                                }

                                MessageBox.Show($"Добро пожаловать, {reader.GetString(reader.GetOrdinal("FullName"))}!", "Успех",
                                    MessageBoxButton.OK, MessageBoxImage.Information);

                                // Переход по роли (логика из твоего документа)
                                if (Application.Current.MainWindow is MainWindow mw)
                                {
                                    Page nextPage;
                                    switch (role)
                                    {
                                        case "Admin":
                                            nextPage = new AdminPage();
                                            break;
                                        case "Manager":
                                            nextPage = new Manager();
                                            break;
                                        default:
                                            nextPage = new User();
                                            break;
                                    }
                                    mw.MainFrame.Navigate(nextPage);
                                }
                                return;
                            }
                        }
                    }
                }
                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegisterLink_Click(object sender, MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
            {
                mw.MainFrame.Navigate(new RegistrationPage());
            }
        }
    }
}